#ifndef OUTPUTSJ_DEF
#define OUTPUTSJ_DEF
void outputSJ(ReadAlignChunk** RAchunk, Parameters& P);
#endif
